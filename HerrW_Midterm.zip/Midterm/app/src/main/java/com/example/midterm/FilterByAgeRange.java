package com.example.midterm;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;


public class FilterByAgeRange extends Fragment {

    public FilterByAgeRange() {
        // Required empty public constructor
    }

    TextView minView,maxView;
    SeekBar seekBarMin, seekBarMax;
    Button button;
    IListener mListen;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_filter_by_age_range, container, false);
        minView = view.findViewById(R.id.min);
        maxView = view.findViewById(R.id.max);
        seekBarMax = view.findViewById(R.id.seekBarMax);
        seekBarMin = view.findViewById(R.id.seekBarMin);
        button = view.findViewById(R.id.ok);
        seekBarMin.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                minView.setText(getString(R.string.min) + " " + progress);
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });

        seekBarMax.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                maxView.setText(getString(R.string.max) + " " + progress);
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (seekBarMin.getProgress() >= seekBarMax.getProgress()) {
                    Toast.makeText(getContext(),getString(R.string.minimax),Toast.LENGTH_LONG).show();
                    return;
                }
                mListen.filterByAgeRange(seekBarMin.getProgress() + " " + seekBarMax.getProgress());
            }
        });

        return view;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
            mListen = (IListener)context;

    }
    public interface IListener {
        void filterByAgeRange(String ageRange);
    }
}