package com.example.midterm;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Collections;


public class FilterByStateFragment extends Fragment {

    public FilterByStateFragment() {
        // Required empty public constructor
    }

    IListener mListen;
    ListView listView;
    ArrayAdapter<String> adapter;
    String TAG = "Filter By State"
;    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        Log.d(TAG, "onCreateView");
        View view = inflater.inflate(R.layout.fragment_filter_by_state, container, false);
        ArrayList<User> users = mListen.getUser();
        ArrayList<String> filteredStates = filter(users);
        Log.d(TAG, filteredStates.toString());
        listView = view.findViewById(R.id.listViewState);
        adapter = new ArrayAdapter<>(getContext(),android.R.layout.simple_list_item_1, android.R.id.text1,filteredStates);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String state = filteredStates.get(position);
                if (state == getString(R.string.AllState)){}
                mListen.filterByStates( state);
            }
        });
        return view;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
            mListen = (IListener)context;
    }

    public interface IListener {
        ArrayList<User> getUser();
        void filterByStates(String state);
    }

    public ArrayList<String> filter(ArrayList<User> users) {
        ArrayList<String> filteredStates = new ArrayList<>();
        for (int i = 0; i < users.size(); i ++) {
            if (!filteredStates.contains(users.get(i).state)) {
                filteredStates.add(users.get(i).state);
            }
        }
        Collections.sort(filteredStates);
        filteredStates.add(0,getString(R.string.AllState));
        return filteredStates;
    }
}