package com.example.midterm;

import android.os.AsyncTask;
import android.util.Log;

import java.util.ArrayList;

public class DoWorkAsync extends AsyncTask<String,Integer,ArrayList<User>> {

    ArrayList<User> users;
    ArrayList<User> filteredUsers;
    String TAG;

    @Override
    protected ArrayList<User> doInBackground(String... strings) {
        Log.d(TAG,"AsyncTask : doInBackground");
        TAG = strings[0];
        String filterType = strings[1];
        users = DataServices.getUsers();

        if (filterType == "State"){

            Log.d(TAG, TAG + "... State");
            String state = strings[2];
            if (state == strings[3])
                return users;
             filteredUsers = new ArrayList<>();
            for (int i = 0; i < users.size(); i ++) {
                if (users.get(i).state.equals(state)) {
                    filteredUsers.add(users.get(i));
                }
            }
            return filteredUsers;
        }
        if (filterType == "AgeRange"){
            Log.d(TAG, TAG + "... AgeRange");
            String[] minimax = strings[2].split(" ");
            int min = Integer.parseInt(minimax[0]);
            int max = Integer.parseInt(minimax[1]);
            filteredUsers = new ArrayList<>();
            for (int i = 0; i < users.size(); i ++) {
                if (users.get(i).age >= min && users.get(i).age <= max) {
                    filteredUsers.add(users.get(i));
                }
            }
            return filteredUsers;
        }

        if (filterType == "Type"){
            Log.d(TAG, TAG + "... type");
            String type = strings[2];
            Log.d(TAG, TAG + "... " + strings[2]);
            filteredUsers = new ArrayList<>();
            for (int i = 0; i < users.size(); i ++) {

                if (users.get(i).group.equals( type)) {
                    filteredUsers.add(users.get(i));
                }
            }
            return filteredUsers;
        }
        return users;
    }

    @Override
    protected void onPostExecute(ArrayList<User> s) {
        Log.d(TAG,"AsyncTask : onPostExecute");
    }

    @Override
    protected void onProgressUpdate(Integer... values) {
        Log.d(TAG,"AsyncTask : onProgressUpdate");
    }

    public ArrayList<User> getUsers() {
        return users;
    }
}
