package com.example.midterm;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class UserAdapter extends ArrayAdapter<User> {
        User user;
        String TAG = "Useradapter";

    public UserAdapter(@NonNull Context context, int resource, @NonNull List<User> objects) {
        super(context, resource, objects);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.user_list, parent, false);
        }

        user = getItem(position);

        TextView name = convertView.findViewById(R.id.userName);
        TextView state = convertView.findViewById(R.id.userState);
        TextView age = convertView.findViewById(R.id.userAge);
        TextView relation = convertView.findViewById(R.id.userRelation);

        ImageView imageView = convertView.findViewById(R.id.imageView);

        name.setText(user.name);
        state.setText(user.state);
        age.setText(String.valueOf(user.age));
        relation.setText(user.group);
        if (user.gender == "Male") {
            imageView.setImageResource(R.drawable.avatar_male);
        } else {
            imageView.setImageResource(R.drawable.avatar_female);
        }
        return convertView;
    }
}
