package com.example.midterm;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import java.util.ArrayList;
import java.util.logging.Filter;

public class MainActivity extends AppCompatActivity implements UsersFragment.IListener, FiltersFragment.IListener,FilterByStateFragment.IListener,FilterByAgeRange.IListener, FilterByType.IListener, SortFragment.IListener{

    UsersFragment usersFragment;
    ArrayList<User> users;
    String TAG = "Main";
    String stateFilter,ageRangeFilters,typeFilter,sortAttribute = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        usersFragment = new UsersFragment();


        //User Fragment
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragmentContainerView, usersFragment)
                .commit();


    }

    @Override
    public void sort( ArrayList<User> users) {
        setTitle(R.string.Sort);
        SortFragment sortFragment = new SortFragment();
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragmentContainerView, sortFragment)
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void filter( ArrayList<User> users) {
        setTitle(R.string.Filter);
        FiltersFragment filtersFragment = new FiltersFragment();
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragmentContainerView, filtersFragment)
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void setUsers(ArrayList<User> users) {
        this.users = users;
        Log.d(TAG,this.users.toString());
    }

    @Override
    public String getFilteredState() {
        return this.stateFilter;
    }

    @Override
    public String getFilteredAgeRange() {
        return this.ageRangeFilters;
    }

    @Override
    public String getFilteredType() {
        return this.typeFilter;
    }

    @Override
    public String getSortAttribute() {
        return this.sortAttribute;
    }

    //Filter Fragment
    @Override
    public void getNextFragment(String filter) {
        Log.d(TAG, "filtering");
        if (filter == getString(R.string.State)) {
            Log.d(TAG, "filter state");
            setTitle(R.string.FilterByState);
            FilterByStateFragment filterByStateFragment = new FilterByStateFragment();
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragmentContainerView, filterByStateFragment)
                    .addToBackStack(null)
                    .commit();
        }
        else if (filter == getString(R.string.AgeRange)){
            Log.d(TAG, "filter age");
            setTitle(R.string.AgeRange);
            FilterByAgeRange filterByAgeRange = new FilterByAgeRange();
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragmentContainerView, filterByAgeRange)
                    .addToBackStack(null)
                    .commit();
        }
        else if (filter == getString(R.string.Type)) {
            Log.d(TAG, "filtering type");
            setTitle(R.string.FilterByType);
            FilterByType filterByType = new FilterByType();

            Log.d(TAG, "filtering type");
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragmentContainerView, filterByType)
                    .addToBackStack(null)
                    .commit();
        }
    }
    //State Listener
    @Override
    public ArrayList<User> getUser() {
        return this.users;
    }
    //FilterByState
    @Override
    public void filterByStates(String state) {
        this.typeFilter = null;
        this.ageRangeFilters = null;
        this.stateFilter = state;
        filteredConditions();
    }
    //FilterByAge
    @Override
    public void filterByAgeRange(String ageRange) {
        this.typeFilter = null;
        this.stateFilter = null;
        this.ageRangeFilters = ageRange;
        filteredConditions();
    }

    public void filteredConditions(){
        for(int i = 0; i <  getSupportFragmentManager().getBackStackEntryCount(); ++i) {
            getSupportFragmentManager().popBackStack();
        }
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragmentContainerView, usersFragment)
                .commit();
    }

    @Override
    public void filterByType(String type) {
        this.ageRangeFilters = null;
        this.stateFilter = null;
        this.typeFilter = type;
        filteredConditions();
    }

    @Override
    public void sortAttribute(String sort) {
        this.sortAttribute = sort;
        getSupportFragmentManager().popBackStack();
    }
}