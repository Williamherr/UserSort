package com.example.midterm;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.concurrent.ExecutionException;


public class UsersFragment extends Fragment {
    String TAG = "UserFragment";
    ArrayList<User> users;
    String filters;
    ListView listView;
    UserAdapter adapter;
    IListener mListen;
    DoWorkAsync task;
    Boolean saveUser;
    String attribute;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu,menu);
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.filter:
                Log.d(TAG,"Fitler");
                mListen.filter(this.users);
                break;
            case R.id.sort:
                Log.d(TAG,"sort");
                mListen.sort(this.users);
                break;

        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_users, container, false);
        Log.d(TAG,"onCreateView");
        getActivity().setTitle(R.string.UserFragment);
        saveUser = false;
        users = new ArrayList<>();

        filterLogic();
        if (mListen.getSortAttribute() != null)
            sortingLogic();

        Log.d(TAG,"Creating listView");
        adapter = new UserAdapter(getContext(), R.layout.user_list,users);
        listView = view.findViewById(R.id.ListView);
        listView.setAdapter(adapter);



        return view;
    }
    public void filterLogic() {
        // If there has been a filter
        if (mListen.getFilteredState() != null) {
            Log.d(TAG,"Filtered State...");
            filters = mListen.getFilteredState();
            task = (DoWorkAsync) new DoWorkAsync().execute(TAG, "State",filters,getString(R.string.AllState));
        } else if (mListen.getFilteredAgeRange() != null) {
            Log.d(TAG,"Filtered Age...");
            filters = mListen.getFilteredAgeRange();
            task = (DoWorkAsync) new DoWorkAsync().execute(TAG, "AgeRange",filters);
        } else if (mListen.getFilteredType() != null){
            Log.d(TAG,"Filtered Type...");
            filters = mListen.getFilteredType();
            task = (DoWorkAsync) new DoWorkAsync().execute(TAG, "Type",filters);
        } else { // No Filters
            saveUser = true;
            task = (DoWorkAsync) new DoWorkAsync().execute(TAG,"");
        }
        try {
            Log.d(TAG,"try.....");
            users = task.get();
            if (saveUser)
                mListen.setUsers(users);

        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void sortingLogic(){
        Log.d(TAG,TAG + " : Sorting");
        attribute = mListen.getSortAttribute();
        if (attribute == getString(R.string.Age)) {
            Collections.sort(users, new Comparator<User>() {
                @Override
                public int compare(User u1, User u2){
                    return u1.age - u2.age;
                }
            });
        } else if (attribute == getString(R.string.Name)){
            Collections.sort(users, new Comparator<User>() {
                @Override
                public int compare(User u1, User u2){
                    return u1.name.toUpperCase().compareTo(u2.name.toUpperCase());
                }
            });
        }
        else if (attribute == getString(R.string.State)){
            Collections.sort(users, new Comparator<User>() {
                @Override
                public int compare(User u1, User u2){
                    return u1.state.toUpperCase().compareTo(u2.state.toUpperCase());
                }
            });
        }
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof IListener) {
            mListen = (IListener)context;
        }
    }



    public interface IListener {
        void sort( ArrayList<User> users);
        void filter( ArrayList<User> users);
        void setUsers(ArrayList<User> users);
        String getFilteredState();
        String getFilteredAgeRange();
        String getFilteredType();
        String getSortAttribute();
    }

}