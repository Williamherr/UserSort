package com.example.midterm;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.Toast;

import java.util.ArrayList;

public class FilterByType extends Fragment {

    public FilterByType() {
        // Required empty public constructor
    }

    RadioGroup radioGroup;
    Button okay;
    String type;
    IListener mListen;
    String TAG = "FilterByType";
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_filter_by_type, container, false);
        Log.d(TAG, TAG + ": onCreateView");
        radioGroup = view.findViewById(R.id.radioGroup);
        okay = view.findViewById(R.id.okButton);
        okay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int checkedId = radioGroup.getCheckedRadioButtonId();
                if (checkedId == R.id.homeRadioButton) {
                    type = getString(R.string.homeRadio);
                } else if (checkedId == R.id.workRadioButton) {
                    type = getString(R.string.workRadio);
                }else if (checkedId == R.id.mobileRadioButton) {
                    type = getString(R.string.mobileRadio);
                }else {
                    Toast.makeText(getContext(),getString(R.string.noChecks),Toast.LENGTH_SHORT).show();
                    return;
                }
                Log.d("FilterByType", type);
                mListen.filterByType(type);
            }
        });

        return view;
    }
    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
            mListen = (IListener)context;

    }
    public interface IListener {
        void filterByType(String type);
    }
}